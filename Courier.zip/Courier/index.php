<?php 
      
      session_start();
      if(isset($_SESSION['type']))
      {
      		if($_SESSION['type'] == "manager") {
				header("Location: manager.php");
	 		} else if($_SESSION['type'] == "courier") {
				header("Location: courier.php");
	 		} else {
	 			header("Location: customer.php");
	 		}
      }

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Courier Management System</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background: url("./assets/3.png");
      opacity: ;
    }
    
    h1 {
      text-align: center;
      margin-top: 20px;
    }

    .login-container {
      width: 300px;
      margin: 20px auto;
      padding: 20px;
      border: 1px solid #ccc;
      border-radius: 5px;
      background-color: #f9f9f9;
    }

    .login-container input[type="email"],
    .login-container input[type="password"] {
      width: calc(100% - 10px);
      margin-bottom: 10px;
      padding: 8px;
      border: 1px solid #ccc;
      border-radius: 3px;
    }

    .login-container button {
      width: 100%;
      padding: 10px;
      background-color: #4CAF50;
      color: white;
      border: none;
      border-radius: 3px;
      cursor: pointer;
    }

    .login-container button:hover {
      background-color: #45a049;
    }
  </style>
</head>
<body>
  <h1>Courier Management System</h1>

  <div class="login-container">
    <h2>Login</h2>
    <form action="session_set.php" class="login_form" onsubmit="return validateAndLogin()" method="POST">
      <label for="userType">Select User Type:</label>
      <select id="userType" name="type">
        <option value="manager">Manager</option>
        <option value="courier">Courier</option>
        <option value="customer">Customer</option>
      </select>
      <input type="email" id="username" placeholder="Username" required name="email">
      <div id="email_error" style="display:none;"> Please fill in your Email</div><br>
      <input type="password" id="password" placeholder="Password" required name="password">
      <div id="pass_error" style="display:none;"> Please fill in your Password</div><br>
      <button name="login">Login</button>
    </form>
    <?php
          if(isset($_REQUEST['error']))
          {
            if($_REQUEST['error']=="if")
            {
              echo "<span style='color:blue'><strong><i>Please Enter Password OR User Name</i></strong></span>";
            }
            if($_REQUEST['error']=="f")
            {
              echo "<span style='color:red'><strong><i>Invalid username or password</i></strong></span>";
            }
            if($_REQUEST['error']=="of")
            {
              echo "<span style='color:red'><strong><i>Your account is not active</strong></i></span>";
            }
            if($_REQUEST['error']=="ok")
            {
              echo "<span style='color:purple;'><strong><i>Thanks for Using</strong></i></span>";
            }
          }

        ?>     
  </div>

  <script>
    function validateAndLogin() {
      var userType = document.getElementById('userType').value;
      var username = document.getElementById('username').value;
      var password = document.getElementById('password').value;
      var emailError = document.getElementById('email_error');
      var passError = document.getElementById('pass_error');

      // Hide any previous error messages
      emailError.style.display = 'none';
      passError.style.display = 'none';

      // Perform login only if both email and password are filled
      if (username.trim() === '') {
        emailError.style.display = 'block';
        return false;
      }

      if (password.trim() === '') {
        passError.style.display = 'block';
        return false;
      }
      return true;
    }
  </script>
</body>
</html>
