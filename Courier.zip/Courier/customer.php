<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Customer Dashboard</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
    }
    
    .container {
      width: 80%;
      margin: 20px auto;
      padding: 20px;
      border: 1px solid #ccc;
      border-radius: 5px;
      background-color: #f9f9f9;
    }

    h1 {
      text-align: center;
    }

    form {
      margin-bottom: 20px;
    }

    form input[type="text"] {
      width: calc(100% - 10px);
      margin-bottom: 10px;
      padding: 8px;
      border: 1px solid #ccc;
      border-radius: 3px;
    }

    form button {
      padding: 10px;
      background-color: #4CAF50;
      color: white;
      border: none;
      border-radius: 3px;
      cursor: pointer;
    }

    form button:hover {
      background-color: #45a049;
    }

    #map {
      height: 400px;
      width: 100%;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Customer Dashboard</h1>

    <h6>Module is on working</h6>
    <!-- Shipper Details Form -->
    <form id="logout" action="logout.php">
      <button type="submit">Logout</button>
    </form>
</body>
</html>