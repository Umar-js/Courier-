<?php
  
  include 'connection.php';


  if(isset($_POST['btn'])) {
    $q = "INSERT INTO `shipments`(`shipment_details`, `shiper_details`, `receiver_details`, `payment`) VALUES ('".$_POST['shipment_details']."','".$_POST['shiper_details']."','".$_POST['receiver_details']."','".$_POST['payment']."')";
    $res = mysqli_query($con,$q);
    if($res) {
      echo "<script>alert('Record added succesfully')</script>";
      echo "<script>window.location = './manager.php';</script>";
    } else {
      echo "<script>alert('Record not added')</script>";
      echo "<script>window.location = './manager.php';</script>";
    }
  }
  if(isset($_POST['update'])) {
    $q = "UPDATE `shipments` SET `shipment_details`='".$_POST['shipment_details']."',`shiper_details`='".$_POST['shiper_details']."',`receiver_details`='".$_POST['receiver_details']."',`payment`='".$_POST['payment']."' WHERE `id`='".$_POST['id']."' ";
    $res = mysqli_query($con,$q);
    if($res) {
      echo "<script>alert('Record updated succesfully')</script>";
      echo "<script>window.location = './manager.php';</script>";
    } else {
      echo "<script>alert('Record not updated')</script>";
      echo "<script>window.location = './manager.php';</script>";
    }
  }
  if(isset($_REQUEST['delete'])) {
    $q = "DELETE FROM `shipments` WHERE `id`='".$_REQUEST['delete']."' ";
    $res = mysqli_query($con,$q);
    if($res) {
      echo "<script>alert('Record deleted succesfully')</script>";
      echo "<script>window.location = './manager.php';</script>";
    } else {
      echo "<script>alert('Record not deleted')</script>";
      echo "<script>window.location = './manager.php';</script>";
    }
  }
  $edit = [0,'','','',''];
  if(isset($_REQUEST['edit'])) {
    $q = "SELECT * FROM `shipments` WHERE `id` = '".$_REQUEST['edit']."' ";
    $res = mysqli_query($con, $q);
    $res = mysqli_fetch_assoc($res);
    $edit[0] = $res['id'];
    $edit[1] = $res['shipment_details'];
    $edit[2] = $res['shiper_details'];
    $edit[3] = $res['receiver_details'];
    $edit[4] = $res['payment'];
  }
  $q = "SELECT * FROM `shipments` ";
  $res = mysqli_query($con,$q);

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manager Dashboard</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background: url(1.jpg);
      opacity: ;

    }
    
    .container {
      width: 80%;
      margin: 20px auto;
      padding: 20px;
      border: 1px solid #ccc;
      border-radius: 5px;
      background-color: #f9f9f9;
      opacity:0.8;
    }

    h1 {
      text-align: center;
    }

    form {
      margin-bottom: 20px;
    }

    form input[type="text"] {
      width: calc(100% - 10px);
      margin-bottom: 10px;
      padding: 8px;
      border: 1px solid #ccc;
      border-radius: 3px;
    }

    form button {
      padding: 10px;
      background-color: #4CAF50;
      color: white;
      border: none;
      border-radius: 3px;
      cursor: pointer;
    }

    form button:hover {
      background-color: #45a049;
    }

    table {
      width: 100%;
      border-collapse: collapse;
    }

    th, td {
      padding: 8px;
      border-bottom: 1px solid #ddd;
      text-align: left;
    }

    th {
      background-color: #4CAF50;
      color: white;
    }
  </style>
</head>
<body>

  <div class="container">
    <h1>Manager Dashboard</h1>

    <!-- Register Shipment Form -->
    <form id="logout" action="logout.php">
      <button type="submit">Logout</button>
    </form>

    <form id="registerShipmentForm" method="POST">
      <h2>Register Shipment</h2>
      <input type="hidden" name="id" value="<?php echo $edit[0] ?>">
      <input type="text" value="<?php echo $edit[1] ?>" name="shipment_details" placeholder="Shipment Details" required>
      <input type="text" value="<?php echo $edit[2] ?>" name="shiper_details" placeholder="Shipper Details" required>
      <input type="text" value="<?php echo $edit[3] ?>" name="receiver_details" placeholder="Receiver Details" required> 
      <input type="text" value="<?php echo $edit[4] ?>" name="payment" placeholder="Parcel Payment Details" required>
      <?php if($edit[0] == 0): ?>
        <button type="submit" name="btn">Register Shipment</button>
      <?php else: ?>
        <button type="submit" name="update">Update Shipment</button>
      <?php endif; ?>
      
    </form>

    <!-- Shipment List -->
    <div id="shipmentList">
      <h2>Shipment List</h2>
      <table>
        <tr>
          <th>Sr#</th>
          <th>Shipment Details</th>
          <th>Shipper Details</th>
          <th>Receiver Details</th>
          <th>Parcel Payment Details</th>
          <th>Action</th>
        </tr>
        <?php $i = 1; while ($row = mysqli_fetch_assoc($res)): ?>
            <tr>
              <th><?php echo $i; $i++; ?></th>
              <td><?php echo $row['shipment_details']; ?></td>
              <td><?php echo $row['shiper_details']; ?></td>
              <td><?php echo $row['receiver_details']; ?></td>
              <td><?php echo $row['payment']; ?></td>
              <td>
                <a href="./manager.php?edit=<?php echo $row['id'] ?>"><i>&#128393;</i></a>
                <a href="./manager.php?delete=<?php echo $row['id'] ?>"><i>X</i></a>
              </td>
            </tr>
        <?php endwhile ?>
      </table>
    </div>
  </div>
</body>
</html>