<?php

	$con = mysqli_connect("localhost", "root", "", "mujtba");
	if(!$con)
	{		
		die("Connection Not Established with DBMS");
	}

?>