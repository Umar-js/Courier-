<?php

	session_start();
	if(!isset($_SESSION['type']))
	{
		echo "<script>window.location = 'index.php?error=if'; </script>";
	}
	unset($_SESSION['type']);
	//session_destroy();
	echo "<script>window.location = 'index.php?error=ok'; </script>";

?>