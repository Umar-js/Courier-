<?php

	 session_start();
	 if(isset($_POST['login']))
	 {
	 	include('connection.php');
	 	$user = mysqli_real_escape_string($con,$_POST['email']);
	 	$pass = mysqli_real_escape_string($con,$_POST['password']);
	 	$type = mysqli_real_escape_string($con,$_POST['type']);
	 	$q = "SELECT * FROM `login` WHERE `email`='$user' AND `password`='$pass' AND `type`='$type' ";
	 	$query = mysqli_query($con,$q);
	 	$row = mysqli_fetch_assoc(mysqli_query($con,$q));
	 	if(mysqli_num_rows($query)!='0')
	 	{
	 		$_SESSION['type'] = $row['type'];
	 		if($row['type'] == "manager") {
				header("Location: manager.php");
	 		} else if($row['type'] == "courier") {
				header("Location: courier.php");
	 		} else {
	 			header("Location: customer.php");
	 		}
		 	die();		
	 	}
	 	else
		 {
		 	header("Location: index.php?error=f");
		 	die();
		 }
	 }
	 else
	 {
	 	header("Location: index.php?error=of");
	 	die();
	 }


?>